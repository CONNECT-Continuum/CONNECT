Instructions for loading documents in version 2.4 and later.

1. Get the LoadDocumentsProgram.zip file and the test_data.zip file from the source code
   tree.  They are located in the directory Product/DBScripts/nhincdb.

2. Unzip the LoadDocumentsProgram.zip file.  This will create a directory called 
   LoadDocumentsProgram.

3. Change directories to the LoadDocumentsProgram directory and unzip the test_data.zip file.  
   This will creat two directories, one called test_data that will contain the test data to 
   be loaded and another one called test_data_processed.  The test data is in the format
   specified in the sampleInputFile.xml file.  You may supply additional (or alternate) test
   data, but it must conform to the format specified in the sampleInputFile.xml file.

4. Modify the hiberanate.cfg.xml and update the connection.driver_class and the comnnection.url
   properties for the database you are using.  There are entries in the file for both MySQL and
   and for Oracle.  Uncomment the ones associated with the database you are using and make sure 
   the entries associated with the other database are commented out.  note that the entries 
   assume that the database you are going to load is located on your local machine.  If it is
   on a different machine, update the url to point to that machine.

   Note:  If you are using an Oracle database, you will need to copy a version of the Oracle
          JDBC drivers to the LoadDocumentsProgram directory.  The Oracle dirvers are not 
          included in the zip file because Oracle requires that users accept the Oracle
          license agreement before receiving the file.  Also note that the Oracle JDBC drivers 
          must be version 10.2 or higher.  If the jar file is not named ojdbc14.jar, then you 
          will need to edit the LoadDocuments.bat (or LoadDocuments.sh if you are using a Unix 
          based operating system) and update the ojdbc.jar entry in the CLASSPATH to the name
          of the jar file.

5. Run the LoadDocuments batch file.  If you are running in a Windows environment, run the 
   LoadDocuments.bat file, and if you are running in a Unix environment, run the LoadDocuments.sh 
   shell script.

6. Verify that the documents were loaded by quering the documents table.

   Note:  When the program runs, it reads document files from the test_data directory and moves 
          them to the test_dat_processed directory when it is through with then.  This is true
          even if the program was not able to load the document into the datbase.  If the 
          documents were not loaded, check for errors in the DocumentLoad.log file that is
          in the LoadDocumentsProgram directory, correct the error, move the test data from
          the test_data_processed directory back into the test_data directory and rerun the
          LoadDocuments batch file/shell script.

Instructions for loading documents in version 2.3 and earlier.

1. Follow the instructions above, but before running the LoadDocuments.[bat or sh] file, edit
   that file and change DocumentRepository.jar to DocumentRepository_2.3.jar.

   Note:  Only the MySQL database is supported in CONNECT versions 2.3 nd earlier.

Special files:

The filespath.properties tells the program where to find the input and output directories.  If
you placed those directories outside the LoadDocumentsProgram directory, youwill need to update
that file to point to the new location.

The hibernate.cfg.xml file contains the database access information.

The log4j.properties file definse where the LoadDocuments.log file will be written.

