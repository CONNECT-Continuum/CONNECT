#!/bin/sh
#
# This batch file loads documents into the Nhinc document repository (for release 2.3) - check readme.txt for setup

CLASSPATH=".:./antlr-2.7.6.jar:asm-attrs.jar:asm.jar:./c3p0-0.9.1.2.jar:./cglib-2.1.3.jar:./commons-collections-2.1.1.jar:./commons-logging-1.1.1.jar:./DocumentRepository.jar:./dom4j-1.6.1.jar:./ehcache-1.2.3.jar:./hibernate3.jar:./jdbc2_0-stdext.jar:./jta.jar:./log4j-1.2.15.jar:./mysql-connector-java-5.1.8-bin.jar:./NhincLib.jar:./ojdbc14.jar" 

java -Xmx1230m -cp $CLASSPATH gov.hhs.fha.nhinc.repository.util.DocumentLoadUtil
