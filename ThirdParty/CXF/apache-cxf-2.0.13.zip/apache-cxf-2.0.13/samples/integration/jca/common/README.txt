
This directory does not contain an Apache CXF demo.  It contains code that
is common to other jca samples . You need to build the code of these directory
before to run the other jca samples. 

NOTE
Please set the CXF_HOME environment variable firt to run the build.

Set CXF environment
=====================
 (Unix) % export CXF_HOME=<cxf-home>
 (Windows) > set CXF_HOME=<cxf-home>

